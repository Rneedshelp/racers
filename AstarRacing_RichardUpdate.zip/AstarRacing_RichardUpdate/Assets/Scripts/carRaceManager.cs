﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class carRaceManager : MonoBehaviour {
    TrackManager track;
    int checkpointsHit = 0;
    int lap=1;
    int totalCheckpoint;
    bool finished = false;

	// Use this for initialization
	void Start ()
    {
        track = GameObject.Find("Track Manager").GetComponent<TrackManager>();
        totalCheckpoint = track.checkPoints.Length;
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.tag=="Checkpoint")//handle the car hitting a checkpoint
        {
            checkpointsHit++;

        }
        else if(collision.gameObject.tag=="Finish")
        {
            if(checkpointsHit>=totalCheckpoint)
            {
                lap += 1;
                track.NextLap(lap,gameObject);
                checkpointsHit = 0;
            }
            if(lap>=track.totalLaps)
            {
                finished = true;
                
            }
        }
    }
}
